/**
 * Production runtime config override.
 * 
 * DEPLOYMENT INSTRUCTIONS:
 * On your production server (smarticket.projects-me.id), add this script tag
 * to index.html BEFORE any other scripts:
 * 
 *   <script>
 *     window.APP_CONFIG = {
 *       API_BASE_URL: 'https://smarticket-api.projects-me.id'
 *     };
 *   </script>
 * 
 * Or serve this file and add: <script src="/config.production.js"></script>
 * 
 * Do NOT commit production URLs into source code.
 * This file is an example/template only.
 */
window.APP_CONFIG = {
  API_BASE_URL: 'https://smarticket-api.projects-me.id',
};
